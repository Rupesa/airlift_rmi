/**
 * Contains the enums with the states of the Hostess, Pilot and Passengers.
 */
package EntitiesState;
