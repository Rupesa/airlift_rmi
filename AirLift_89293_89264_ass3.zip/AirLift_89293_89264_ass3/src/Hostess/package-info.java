/**
 * Main package of Hostess. Contains the main program that starts the
 * hostess lifecycle.
 */
package Hostess;
