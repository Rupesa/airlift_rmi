/**
 * Common infrastructure.
 */
package commInfra;
