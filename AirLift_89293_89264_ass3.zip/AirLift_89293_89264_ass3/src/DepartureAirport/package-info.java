/**
 * Main package that contains the classes that launch the main program that will
 * register the DepartureAirport on the registry.
 */
package DepartureAirport;
