/**
 * Main package that contains the classes that launch the main program that will
 * register the DestinationAirport on the registry.
 */
package DestinationAirport;
