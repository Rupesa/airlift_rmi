/**
 * Main package that contains the classes that launch the main program that will
 * register the Plane on the registry.
 */
package Plane;
