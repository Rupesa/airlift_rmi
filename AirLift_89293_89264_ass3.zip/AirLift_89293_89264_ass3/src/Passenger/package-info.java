/**
 * Main package of Passengers. Contains the main program that starts the
 * passengers lifecycle.
 */
package Passenger;
