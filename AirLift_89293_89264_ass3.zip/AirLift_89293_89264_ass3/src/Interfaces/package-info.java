/**
 * Interfaces used to communicate with other entities with Java RMI.
 */
package Interfaces;
