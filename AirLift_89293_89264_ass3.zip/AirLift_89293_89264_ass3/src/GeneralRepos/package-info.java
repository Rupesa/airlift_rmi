/**
 * Main package that contains the classes that launch the main program that will
 * register the GeneralRepos on the registry.
 */
package GeneralRepos;
