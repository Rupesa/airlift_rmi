/**
 * Main package that contains the classes that launches the Pilot thread and
 * communicates with the other shared regions by RMI.
 */
package Pilot;
