/**
 * Package of Simulation Parameters. Contains the parameters used for the simulation.
 */
package SimulationParameters;
